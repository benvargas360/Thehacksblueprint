# The Hacks Blueprint – Landing

## Local dev
```bash
npm install
npm run dev
```

## Deploy on Vercel
- Build command: npm run build
- Output directory: dist
